package settlement;

import java.util.List;

public class Statistics {
    private final int count;
    private final double mean;
    private final double min;
    private final double max;
    private final double standardDeviation;

    public Statistics(int count, double mean, double min, double max, double standardDeviation) {
        this.count = count;
        this.mean = mean;
        this.min = min;
        this.max = max;
        this.standardDeviation = standardDeviation;
    }

    public static Statistics from(List<Double> values) {
        if (values.isEmpty()) {
            return new Statistics(0, Double.NaN, Double.NaN, Double.NaN, Double.NaN);
        }

        double sum = 0;
        double min = values.get(0);
        double max = values.get(0);

        for (double value : values) {
            sum += value;
            if (Double.compare(value, min) < 0) {
                min = value;
            }
            if (Double.compare(value, max) > 0) {
                max = value;
            }
        }

        double mean = sum / values.size();
        double squaredDifferences = 0;
        for (double value : values) {
            double difference = value - mean;
            squaredDifferences += difference * difference;
        }

        double standardDeviation = Math.sqrt(squaredDifferences / values.size());
        return new Statistics(values.size(), mean, min, max, standardDeviation);
    }

    public int getCount() { return count; }
    public double getMean() { return mean; }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getStandardDeviation() { return standardDeviation; }
}
