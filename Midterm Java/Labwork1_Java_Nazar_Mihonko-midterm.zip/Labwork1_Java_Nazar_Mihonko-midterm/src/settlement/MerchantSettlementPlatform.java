package settlement;

import exceptions.InvalidPaymentDataException;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.ToDoubleFunction;

public class MerchantSettlementPlatform {
    private final Set<SettlementBatch> batches = new LinkedHashSet<>();

    public List<SettlementBatch> getBatches() { return List.copyOf(batches); }

    public void addBatch(SettlementBatch batch) {
        if (batch == null) {
            throw new InvalidPaymentDataException("batch must not be null");
        }
        batches.add(batch);
    }

    private void sortByMetricAscending(ToDoubleFunction<SettlementBatch> metric) {
        reorderBatches(sortByMetric(metric, true));
    }

    private void sortByMetricDescending(ToDoubleFunction<SettlementBatch> metric) {
        reorderBatches(sortByMetric(metric, false));
    }

    private List<SettlementBatch> sortByMetric(ToDoubleFunction<SettlementBatch> metric, boolean ascending) {
        List<SettlementBatch> sortedBatches = new ArrayList<>(batches);
        sortedBatches.sort((first, second) -> {
            double firstValue = metric.applyAsDouble(first);
            double secondValue = metric.applyAsDouble(second);
            boolean firstMissing = Double.isNaN(firstValue);
            boolean secondMissing = Double.isNaN(secondValue);

            if (firstMissing && secondMissing) {
                return 0;
            }
            if (firstMissing) {
                return 1;
            }
            if (secondMissing) {
                return -1;
            }
            if (ascending) {
                return Double.compare(firstValue, secondValue);
            }
            return Double.compare(secondValue, firstValue);
        });
        return sortedBatches;
    }

    private void reorderBatches(List<SettlementBatch> sortedBatches) {
        batches.clear();
        batches.addAll(sortedBatches);
    }

    public List<SettlementBatch> getBatchesSortedByMaximumEffectiveSettlementValueDescending() {
        sortByMaximumEffectiveSettlementValueDescending();
        return getBatches();
    }

    public List<SettlementBatch> getBatchesSortedByMaximumCardInterchangePlusCostDescending() {
        sortByMaximumCardInterchangePlusCostDescending();
        return getBatches();
    }

    public void sortByMaximumEffectiveSettlementValueDescending() {
        sortByMetricDescending(SettlementBatch::calculateMaximumEffectiveSettlementValue);
    }

    public void sortByMaximumCardInterchangePlusCostDescending() {
        sortByMetricDescending(SettlementBatch::calculateMaximumCardInterchangePlusCostEur);
    }

    public void sortByAverageAscending() {
        sortByMetricAscending(SettlementBatch::calculateAverage);
    }

    public void sortByAverageDescending() {
        sortByMetricDescending(SettlementBatch::calculateAverage);
    }

    public void sortByStandardDeviation() {
        sortByMetricAscending(SettlementBatch::calculateStandardDeviation);
    }

    public void sortByMaximum() {
        sortByMetricAscending(SettlementBatch::calculateMaximumEffectiveSettlementValue);
    }

    public void sortByCardInterchangePlusCostAscending() {
        sortByMetricAscending(batch -> batch.calculateCardInterchangeStatistics().getMean());
    }

    public void sortByCardInterchangePlusCostDescending() {
        sortByMaximumCardInterchangePlusCostDescending();
    }

    public void sortByInternationalRequiredSendAmountAscending(double targetAmountEur) {
        sortByMetricAscending(
                batch -> batch.calculateInternationalRequiredSendAmountStatistics(targetAmountEur).getMean());
    }

    public void sortByInternationalRequiredSendAmountDescending(double targetAmountEur) {
        sortByMetricDescending(
                batch -> batch.calculateInternationalRequiredSendAmountStatistics(targetAmountEur).getMean());
    }

    public void sortByDigitalWalletInstantPayoutBenefitAscending(double annualReturnRate) {
        sortByMetricAscending(
                batch -> batch.calculateDigitalWalletInstantPayoutBenefitStatistics(annualReturnRate).getMean());
    }

    public void sortByDigitalWalletInstantPayoutBenefitDescending(double annualReturnRate) {
        sortByMetricDescending(
                batch -> batch.calculateDigitalWalletInstantPayoutBenefitStatistics(annualReturnRate).getMean());
    }

    public void sortByBnplPresentValueOfInstallmentsAscending() {
        sortByMetricAscending(batch -> batch.calculateBnplPresentValueStatistics().getMean());
    }

    public void sortByBnplPresentValueOfInstallmentsDescending() {
        sortByMetricDescending(batch -> batch.calculateBnplPresentValueStatistics().getMean());
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("Merchant settlement platform - base currency EUR\n");
        for (SettlementBatch batch : batches) {
            result.append(batch).append('\n');
        }
        return result.toString();
    }
}
