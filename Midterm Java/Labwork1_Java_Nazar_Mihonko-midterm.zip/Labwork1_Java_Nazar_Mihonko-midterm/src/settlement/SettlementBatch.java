package settlement;

import payments.BNPLPayment;
import payments.CardPayment;
import payments.DigitalWalletPayment;
import payments.InternationalBankTransfer;
import payments.Payment;
import exceptions.InvalidPaymentDataException;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class SettlementBatch {
    private final String batchName;
    private final Set<Payment> payments = new LinkedHashSet<>();

    public SettlementBatch(String batchName) {
        if (batchName == null || batchName.isBlank()) {
            throw new InvalidPaymentDataException("batchName must not be null or blank");
        }
        this.batchName = batchName.trim();
    }

    public String getBatchName() { return batchName; }
    public List<Payment> getPayments() { return List.copyOf(payments); }

    public void addPayment(Payment payment) {
        if (payment == null) {
            throw new InvalidPaymentDataException("payment must not be null");
        }
        payments.add(payment);
    }

    public double calculateAverage() {
        return calculateEffectiveSettlementStatistics().getMean();
    }

    public double calculateMaximumEffectiveSettlementValue() {
        double maximum = Double.NaN;
        for (Payment payment : payments) {
            double value = payment.calculateEffectiveSettlementValue();
            if (Double.isNaN(maximum) || Double.compare(value, maximum) > 0) {
                maximum = value;
            }
        }
        return maximum;
    }

    public double calculateMaximumCardInterchangePlusCostEur() {
        double maximum = Double.NaN;
        for (Payment payment : payments) {
            if (payment instanceof CardPayment cardPayment) {
                double value = cardPayment.calculateInterchangePlusCost() * cardPayment.getExchangeRate();
                if (Double.isNaN(maximum) || Double.compare(value, maximum) > 0) {
                    maximum = value;
                }
            }
        }
        return maximum;
    }

    public Statistics calculateEffectiveSettlementStatistics() {
        List<Double> values = new ArrayList<>();
        for (Payment payment : payments) {
            values.add(payment.calculateEffectiveSettlementValue());
        }
        return Statistics.from(values);
    }

    public Statistics calculateCardInterchangeStatistics() {
        List<Double> values = new ArrayList<>();
        for (Payment payment : payments) {
            if (payment instanceof CardPayment cardPayment) {
                values.add(cardPayment.calculateInterchangePlusCost() * cardPayment.getExchangeRate());
            }
        }
        return Statistics.from(values);
    }

    public double calculateAverageCardInterchangePlusCostEur() {
        return calculateCardInterchangeStatistics().getMean();
    }

    public Statistics calculateInternationalRequiredSendAmountStatistics(double targetAmountEur) {
        List<Double> values = new ArrayList<>();
        for (Payment payment : payments) {
            if (payment instanceof InternationalBankTransfer bankTransfer) {
                double sourceCurrencyAmount = bankTransfer.calculateRequiredSendAmount(targetAmountEur);
                values.add(sourceCurrencyAmount * bankTransfer.getExchangeRate());
            }
        }
        return Statistics.from(values);
    }

    public double calculateAverageInternationalRequiredSendAmountEur(double targetAmountEur) {
        return calculateInternationalRequiredSendAmountStatistics(targetAmountEur).getMean();
    }

    public Statistics calculateDigitalWalletInstantPayoutBenefitStatistics(double annualReturnRate) {
        List<Double> values = new ArrayList<>();
        for (Payment payment : payments) {
            if (payment instanceof DigitalWalletPayment walletPayment) {
                values.add(walletPayment.calculateInstantPayoutEconomicBenefit(annualReturnRate));
            }
        }
        return Statistics.from(values);
    }

    public double calculateAverageDigitalWalletInstantPayoutBenefitEur(double annualReturnRate) {
        return calculateDigitalWalletInstantPayoutBenefitStatistics(annualReturnRate).getMean();
    }

    public Statistics calculateBnplPresentValueStatistics() {
        List<Double> values = new ArrayList<>();
        for (Payment payment : payments) {
            if (payment instanceof BNPLPayment bnplPayment) {
                values.add(bnplPayment.calculatePresentValueOfInstallments() * bnplPayment.getExchangeRate());
            }
        }
        return Statistics.from(values);
    }

    public double calculateAverageBnplPresentValueOfInstallmentsEur() {
        return calculateBnplPresentValueStatistics().getMean();
    }

    public double calculateMinimum() {
        return calculateEffectiveSettlementStatistics().getMin();
    }

    public double calculateMaximum() {
        return calculateMaximumEffectiveSettlementValue();
    }

    public double calculateStandardDeviation() {
        return calculateEffectiveSettlementStatistics().getStandardDeviation();
    }

    public String getStatisticsSummary() {
        if (payments.isEmpty()) {
            return batchName + ": average=N/A, min=N/A, max=N/A, population SD=N/A (empty batch)";
        }
        return String.format(
                "%s: average=%.2f EUR, min=%.2f EUR, max=%.2f EUR, population SD=%.2f EUR",
                batchName, calculateAverage(), calculateMinimum(), calculateMaximum(), calculateStandardDeviation());
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder(batchName + " (" + payments.size() + " payments)\n");
        for (Payment payment : payments) {
            result.append("  ").append(payment).append('\n');
        }
        result.append("  maximumEffectiveSettlementValue=")
                .append(formatValue(calculateMaximumEffectiveSettlementValue()))
                .append(" EUR\n");
        result.append("  maximumCardInterchangePlusCost=")
                .append(formatValue(calculateMaximumCardInterchangePlusCostEur()))
                .append(" EUR\n");
        return result.toString();
    }

    private String formatValue(double value) {
        if (Double.isNaN(value)) {
            return "N/A";
        }
        return String.format(Locale.ROOT, "%.2f", value);
    }
}
