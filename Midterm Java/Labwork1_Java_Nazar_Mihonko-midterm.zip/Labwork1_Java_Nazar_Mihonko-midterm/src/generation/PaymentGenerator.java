package generation;

import payments.Payment;
import payments.CardPayment;
import payments.InternationalBankTransfer;
import payments.DigitalWalletPayment;
import payments.BNPLPayment;
import settlement.SettlementBatch;
import exceptions.InvalidPaymentDataException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class PaymentGenerator {
    private static final double MIN_AMOUNT = 10;
    private static final double MIN_BANK_AMOUNT = 100;
    private static final double MAX_AMOUNT = 5000;
    private static final int MAX_SETTLEMENT_DAYS = 7;
    private static final double MIN_ANNUAL_DISCOUNT_RATE = 0.01;
    private static final double MAX_ANNUAL_DISCOUNT_RATE = 0.15;
    private static final double MIN_INTERCHANGE_RATE = 0.002;
    private static final double MAX_INTERCHANGE_RATE = 0.018;
    private static final double MIN_NETWORK_RATE = 0.0005;
    private static final double MAX_NETWORK_RATE = 0.002;
    private static final double MIN_PROCESSOR_RATE = 0.001;
    private static final double MAX_PROCESSOR_RATE = 0.005;
    private static final double MIN_FIXED_CARD_FEE = 0.05;
    private static final double MAX_FIXED_CARD_FEE = 0.30;
    private static final double MIN_CROSS_BORDER_RATE = 0.003;
    private static final double MAX_CROSS_BORDER_RATE = 0.015;
    private static final double MIN_SENDER_FEE = 2;
    private static final double MAX_SENDER_FEE = 15;
    private static final double MIN_CORRESPONDENT_FEE = 0;
    private static final double MAX_CORRESPONDENT_FEE = 10;
    private static final double MIN_RECEIVER_FEE = 0;
    private static final double MAX_RECEIVER_FEE = 5;
    private static final double MIN_FX_SPREAD = 0.002;
    private static final double MAX_FX_SPREAD = 0.02;
    private static final double MIN_WALLET_FEE_RATE = 0.01;
    private static final double MAX_WALLET_FEE_RATE = 0.03;
    private static final double MIN_FIXED_WALLET_FEE = 0.05;
    private static final double MAX_FIXED_WALLET_FEE = 0.30;
    private static final double MIN_INSTANT_PAYOUT_RATE = 0.005;
    private static final double MAX_INSTANT_PAYOUT_RATE = 0.015;
    private static final double MIN_INSTANT_FEE = 0.10;
    private static final double MAX_INSTANT_FEE = 0.50;
    private static final String[] CURRENCIES = {"EUR", "USD", "GBP"};
    // Illustrative EUR per unit of source currency, not live market quotes.
    private static final double[] EUR_EXCHANGE_RATES = {1.0, 0.92, 1.17};
    private static final int PAYMENT_TYPE_COUNT = 4;
    private static final int MIN_INSTALLMENTS = 3;
    private static final int MAX_INSTALLMENTS = 12;
    private static final double MIN_BNPL_FEE_RATE = 0.02;
    private static final double MAX_BNPL_FEE_RATE = 0.06;
    private static final double MIN_BNPL_FIXED_FEE = 0.10;
    private static final double MAX_BNPL_FIXED_FEE = 0.50;
    private final Random random;
    private int nextTransactionNumber = 1;

    public PaymentGenerator() {
        random = new Random();
    }

    public PaymentGenerator(long seed) {
        random = new Random(seed);
    }

    public Payment generatePayment() {
        return generatePayment(random.nextInt(PAYMENT_TYPE_COUNT));
    }

    public List<SettlementBatch> generateBatches(int batchCount, int paymentsPerBatch) {
        if (batchCount < 0 || paymentsPerBatch < 0) {
            throw new InvalidPaymentDataException("Batch and payment counts must be >= 0");
        }
        List<SettlementBatch> batches = new ArrayList<>();
        for (int batchIndex = 0; batchIndex < batchCount; batchIndex++) {
            SettlementBatch batch = new SettlementBatch("Merchant batch " + (batchIndex + 1));
            List<Payment> generated = new ArrayList<>();
            for (int i = 0; i < paymentsPerBatch; i++) {
                // Guarantee all four types when there is room, then select randomly.
                if (i < PAYMENT_TYPE_COUNT) {
                    generated.add(generatePayment(i));
                } else {
                    generated.add(generatePayment());
                }
            }
            Collections.shuffle(generated, random);
            generated.forEach(batch::addPayment);
            batches.add(batch);
        }
        return batches;
    }

    private double between(double minimum, double maximum) {
        return minimum + random.nextDouble() * (maximum - minimum);
    }

    private Payment generatePayment(int type) {
        int currencyIndex = random.nextInt(CURRENCIES.length);
        String currency = CURRENCIES[currencyIndex];
        double exchangeRate = EUR_EXCHANGE_RATES[currencyIndex];
        String id = "TX-" + nextTransactionNumber++;
        double amount = between(type == 1 ? MIN_BANK_AMOUNT : MIN_AMOUNT, MAX_AMOUNT);
        int days = random.nextInt(MAX_SETTLEMENT_DAYS + 1);
        double discountRate = between(MIN_ANNUAL_DISCOUNT_RATE, MAX_ANNUAL_DISCOUNT_RATE);
        double spread = currencyIndex == 0 ? 0 : between(MIN_FX_SPREAD, MAX_FX_SPREAD);
        return switch (type) {
            case 0 -> new CardPayment(id, amount, currency, exchangeRate, days, discountRate,
                    between(MIN_INTERCHANGE_RATE, MAX_INTERCHANGE_RATE),
                    between(MIN_NETWORK_RATE, MAX_NETWORK_RATE),
                    between(MIN_PROCESSOR_RATE, MAX_PROCESSOR_RATE),
                    between(MIN_FIXED_CARD_FEE, MAX_FIXED_CARD_FEE),
                    between(MIN_CROSS_BORDER_RATE, MAX_CROSS_BORDER_RATE), random.nextBoolean());
            case 1 -> new InternationalBankTransfer(id, amount, currency, exchangeRate, days, discountRate,
                    between(MIN_SENDER_FEE, MAX_SENDER_FEE),
                    between(MIN_CORRESPONDENT_FEE, MAX_CORRESPONDENT_FEE),
                    between(MIN_RECEIVER_FEE, MAX_RECEIVER_FEE), spread);
            case 2 -> new DigitalWalletPayment(id, amount, currency, exchangeRate, days, discountRate,
                    between(MIN_WALLET_FEE_RATE, MAX_WALLET_FEE_RATE),
                    between(MIN_FIXED_WALLET_FEE, MAX_FIXED_WALLET_FEE), spread,
                    between(MIN_INSTANT_PAYOUT_RATE, MAX_INSTANT_PAYOUT_RATE),
                    between(MIN_INSTANT_FEE, MAX_INSTANT_FEE), random.nextBoolean());
            case 3 -> new BNPLPayment(id, amount, currency, exchangeRate, days, discountRate,
                    MIN_INSTALLMENTS + random.nextInt(MAX_INSTALLMENTS - MIN_INSTALLMENTS + 1),
                    between(MIN_BNPL_FEE_RATE, MAX_BNPL_FEE_RATE),
                    between(MIN_BNPL_FIXED_FEE, MAX_BNPL_FIXED_FEE));
            default -> throw new InvalidPaymentDataException("Unknown payment type: " + type);
        };
    }
}
