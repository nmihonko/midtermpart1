package input;

import exceptions.InvalidPaymentDataException;
import payments.Payment;
import settlement.MerchantSettlementPlatform;
import settlement.SettlementBatch;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class PaymentFileReader {
    private final List<String> errors = new ArrayList<>();
    private int loadedPaymentCount;

    public List<String> getErrors() { return List.copyOf(errors); }
    public int getLoadedPaymentCount() { return loadedPaymentCount; }

    public MerchantSettlementPlatform read(Path path) throws IOException {
        errors.clear();
        loadedPaymentCount = 0;
        MerchantSettlementPlatform platform = new MerchantSettlementPlatform();
        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                if (lineNumber == 1 && line.startsWith("\uFEFF")) {
                    line = line.substring(1);
                }
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }
                try {
                    if (line.contains("\"")) {
                        throw new InvalidPaymentDataException("Quoted fields are not supported");
                    }
                    String[] fields = line.split(",", -1);
                    for (int i = 0; i < fields.length; i++) {
                        fields[i] = fields[i].trim();
                    }
                    Payment payment = PaymentFromCsvCreator.createPayment(fields);
                    payment.calculateEffectiveSettlementValue();
                    SettlementBatch matchingBatch = null;
                    for (SettlementBatch batch : platform.getBatches()) {
                        if (batch.getBatchName().equals(fields[0])) {
                            matchingBatch = batch;
                            break;
                        }
                    }
                    if (matchingBatch == null) {
                        matchingBatch = new SettlementBatch(fields[0]);
                        platform.addBatch(matchingBatch);
                    }
                    matchingBatch.addPayment(payment);
                    loadedPaymentCount++;
                } catch (InvalidPaymentDataException exception) {
                    errors.add("Line " + lineNumber + ": " + exception.getMessage());
                }
            }
        }
        return platform;
    }
}
