package input;

import exceptions.InvalidPaymentDataException;
import payments.CardPayment;
import payments.DigitalWalletPayment;
import payments.InternationalBankTransfer;
import payments.Payment;
import payments.BNPLPayment;

public class PaymentFromCsvCreator {
    public static Payment createPayment(String[] fields) {
        if (fields == null || fields.length < 2) {
            throw new InvalidPaymentDataException("Missing batch name or payment type");
        }
        String type = fields[1];
        int expectedCount;
        if ("CARD".equals(type) || "WALLET".equals(type)) {
            expectedCount = 14;
        } else if ("BANK".equals(type)) {
            expectedCount = 12;
        } else if ("BNPL".equals(type)) {
            expectedCount = 11;
        } else {
            throw new InvalidPaymentDataException("Unknown payment type: " + type);
        }
        if (fields.length != expectedCount) {
            throw new InvalidPaymentDataException(type + " needs " + expectedCount
                    + " fields, but received " + fields.length);
        }
        for (int i = 0; i < fields.length; i++) {
            if (fields[i] == null || fields[i].isBlank()) {
                throw new InvalidPaymentDataException("Missing value in column " + (i + 1));
            }
        }
        String id = fields[2];
        double amount = number(fields[3], "amount");
        String currency = fields[4];
        double exchangeRate = number(fields[5], "exchangeRate");
        int days;
        try {
            days = Integer.parseInt(fields[6]);
        } catch (NumberFormatException exception) {
            throw new InvalidPaymentDataException("settlementDays must be a whole number: " + fields[6]);
        }
        double discountRate = number(fields[7], "annualDiscountRate");
        if ("CARD".equals(type)) {
            return new CardPayment(id, amount, currency, exchangeRate, days, discountRate,
                    number(fields[8], "interchangeRate"), number(fields[9], "networkRate"),
                    number(fields[10], "processorRate"), number(fields[11], "fixedProcessorFee"),
                    number(fields[12], "crossBorderRate"), booleanValue(fields[13]));
        }
        if ("BANK".equals(type)) {
            return new InternationalBankTransfer(id, amount, currency, exchangeRate, days, discountRate,
                    number(fields[8], "senderBankFee"), number(fields[9], "correspondentBankFee"),
                    number(fields[10], "receiverBankFee"), number(fields[11], "fxSpread"));
        }
        if ("BNPL".equals(type)) {
            int installmentCount;
            try {
                installmentCount = Integer.parseInt(fields[8]);
            } catch (NumberFormatException exception) {
                throw new InvalidPaymentDataException("installmentCount must be a whole number: " + fields[8]);
            }
            return new BNPLPayment(id, amount, currency, exchangeRate, days, discountRate,
                    installmentCount, number(fields[9], "merchantFeeRate"), number(fields[10], "fixedProviderFee"));
        }
        return new DigitalWalletPayment(id, amount, currency, exchangeRate, days, discountRate,
                number(fields[8], "walletFeeRate"), number(fields[9], "fixedWalletFee"),
                number(fields[10], "fxSpread"), number(fields[11], "instantPayoutRate"),
                number(fields[12], "minimumInstantFee"), booleanValue(fields[13]));
    }

    private static double number(String text, String name) {
        try {
            double value = Double.parseDouble(text);
            if (!Double.isFinite(value)) {
                throw new InvalidPaymentDataException(name + " must be finite");
            }
            return value;
        } catch (NumberFormatException exception) {
            throw new InvalidPaymentDataException(name + " is not a number: " + text);
        }
    }

    private static boolean booleanValue(String text) {
        if ("true".equalsIgnoreCase(text)) {
            return true;
        }
        if ("false".equalsIgnoreCase(text)) {
            return false;
        }
        throw new InvalidPaymentDataException("Boolean must be true or false: " + text);
    }
}
