package payments;

import exceptions.InvalidPaymentDataException;

public class BNPLPayment extends Payment {
    private final int installmentCount;
    private final double merchantFeeRate;
    private final double fixedProviderFee;

    public BNPLPayment(String transactionId, double amount, String currency, double exchangeRate,
                       int settlementDays, double annualDiscountRate, int installmentCount,
                       double merchantFeeRate, double fixedProviderFee) {
        super(transactionId, amount, currency, exchangeRate, settlementDays, annualDiscountRate);
        if (installmentCount < 1 || installmentCount > 36) {
            throw new InvalidPaymentDataException("installmentCount must be between 1 and 36");
        }
        this.installmentCount = installmentCount;
        this.merchantFeeRate = requireRate("merchantFeeRate", merchantFeeRate, true);
        this.fixedProviderFee = requireNonNegative("fixedProviderFee", fixedProviderFee);
    }

    public int getInstallmentCount() { return installmentCount; }
    public double getMerchantFeeRate() { return merchantFeeRate; }
    public double getFixedProviderFee() { return fixedProviderFee; }

    @Override
    public double calculateEffectiveSettlementValue() {
        double providerFee = getAmount() * merchantFeeRate + fixedProviderFee;
        double netAmount = getAmount() - providerFee;
        requireFiniteResult(netAmount);
        double installmentAmount = netAmount / installmentCount;
        double presentValue = 0;

        for (int month = 1; month <= installmentCount; month++) {
            // First receipt is one month plus settlement delay after the transaction.
            double yearsUntilPayment = month / 12.0 + getSettlementDays() / 365.0;
            double discountFactor = Math.pow(1 + getAnnualDiscountRate(), yearsUntilPayment);
            requireFiniteResult(discountFactor);
            double discountedInstallment = installmentAmount / discountFactor;
            presentValue = presentValue + discountedInstallment;
        }

        double effectiveSettlementValue = presentValue * getExchangeRate();
        return requireFiniteResult(effectiveSettlementValue);
    }

    // Gross monthly schedule in source currency, before fees and extra processing delay.
    public double calculatePresentValueOfInstallments() {
        double installmentAmount = getAmount() / installmentCount;
        double presentValue = 0;
        for (int month = 1; month <= installmentCount; month++) {
            double yearsUntilPayment = month / 12.0;
            double discountFactor = Math.pow(1 + getAnnualDiscountRate(), yearsUntilPayment);
            requireFiniteResult(discountFactor);
            presentValue = presentValue + installmentAmount / discountFactor;
        }
        return requireFiniteResult(presentValue);
    }

    @Override
    public String toString() {
        return getBasicPaymentInformation() + String.format(
                "%n    installmentCount=%d monthly payments, merchantFeeRate=%.4f, fixedProviderFee=%.2f %s"
                + "%n    effectiveSettlementValue=%.2f EUR; grossInstallmentPresentValue=%.2f %s",
                installmentCount, merchantFeeRate, fixedProviderFee, getCurrency(),
                calculateEffectiveSettlementValue(), calculatePresentValueOfInstallments(), getCurrency());
    }
}
