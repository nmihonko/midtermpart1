package payments;

import exceptions.InvalidPaymentDataException;

import java.util.Locale;

public abstract class Payment {
    public static final String SETTLEMENT_CURRENCY = "EUR";
    private final String transactionId;
    private final double amount;
    private final String currency;
    private final double exchangeRate;
    private final int settlementDays;
    private final double annualDiscountRate;

    protected Payment(String transactionId, double amount, String currency,
                      double exchangeRate, int settlementDays, double annualDiscountRate) {
        this.transactionId = requireText("transactionId", transactionId);
        this.amount = requirePositive("amount", amount);
        this.currency = requireText("currency", currency).toUpperCase(Locale.ROOT);
        this.exchangeRate = requirePositive("exchangeRate", exchangeRate);
        if (settlementDays < 0) {
            throw new InvalidPaymentDataException("settlementDays must be >= 0");
        }
        this.settlementDays = settlementDays;
        this.annualDiscountRate = requireNonNegative("annualDiscountRate", annualDiscountRate);
    }

    public String getTransactionId() { return transactionId; }
    public double getAmount() { return amount; }
    public String getCurrency() { return currency; }
    public double getExchangeRate() { return exchangeRate; }
    public int getSettlementDays() { return settlementDays; }
    public double getAnnualDiscountRate() { return annualDiscountRate; }

    public String getBasicPaymentInformation() {
        return String.format(
                "%s id=%s, amount=%.2f %s, exchangeRate=%.4f EUR/%s, "
                + "settlementDays=%d days, annualDiscountRate=%.4f",
                getClass().getSimpleName(), transactionId, amount, currency,
                exchangeRate, currency, settlementDays, annualDiscountRate);
    }

    public abstract double calculateEffectiveSettlementValue();

    protected static String requireText(String name, String value) {
        if (value == null || value.isBlank()) {
            throw new InvalidPaymentDataException(name + " must not be null or blank");
        }
        return value.trim();
    }

    protected static double requirePositive(String name, double value) {
        if (!Double.isFinite(value) || value <= 0) {
            throw new InvalidPaymentDataException(name + " must be finite and > 0");
        }
        return value;
    }

    protected static double requireNonNegative(String name, double value) {
        if (!Double.isFinite(value) || value < 0) {
            throw new InvalidPaymentDataException(name + " must be finite and >= 0");
        }
        return value;
    }

    protected static double requireRate(String name, double value, boolean allowOne) {
        requireNonNegative(name, value);
        if (allowOne) {
            if (value > 1) {
                throw new InvalidPaymentDataException(name + " must be <= 1");
            }
        } else {
            if (value >= 1) {
                throw new InvalidPaymentDataException(name + " must be < 1");
            }
        }
        return value;
    }

    protected static double requireFiniteResult(double value) {
        if (!Double.isFinite(value)) {
            throw new InvalidPaymentDataException("Calculation exceeds the supported numeric range");
        }
        return value;
    }

}
