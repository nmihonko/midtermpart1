package payments;

import java.util.Locale;

public class CardPayment extends Payment {
    private final double interchangeRate;
    private final double networkRate;
    private final double processorRate;
    private final double fixedProcessorFee;
    private final double crossBorderRate;
    private final boolean international;

    public CardPayment(String transactionId, double amount, String currency, double exchangeRate,
                       int settlementDays, double annualDiscountRate, double interchangeRate,
                       double networkRate, double processorRate, double fixedProcessorFee,
                       double crossBorderRate, boolean international) {
        super(transactionId, amount, currency, exchangeRate, settlementDays, annualDiscountRate);
        this.interchangeRate = requireRate("interchangeRate", interchangeRate, true);
        this.networkRate = requireRate("networkRate", networkRate, true);
        this.processorRate = requireRate("processorRate", processorRate, true);
        this.fixedProcessorFee = requireNonNegative("fixedProcessorFee", fixedProcessorFee);
        this.crossBorderRate = requireRate("crossBorderRate", crossBorderRate, true);
        this.international = international;
    }

    public double getInterchangeRate() { return interchangeRate; }
    public double getNetworkRate() { return networkRate; }
    public double getProcessorRate() { return processorRate; }
    public double getFixedProcessorFee() { return fixedProcessorFee; }
    public double getCrossBorderRate() { return crossBorderRate; }
    public boolean isInternational() { return international; }

    public double calculateInterchangePlusCost() {
        return requireFiniteResult(getAmount() * interchangeRate + getAmount() * networkRate
                + (getAmount() * processorRate + fixedProcessorFee));
    }

    @Override
    public double calculateEffectiveSettlementValue() {
        double interchangeFee = getAmount() * interchangeRate;
        double networkFee = getAmount() * networkRate;
        double processorFee = getAmount() * processorRate + fixedProcessorFee;
        double crossBorderFee = 0;
        if (international) {
            crossBorderFee = getAmount() * crossBorderRate;
        }

        double cardProcessingCost = interchangeFee + networkFee + processorFee + crossBorderFee;
        double netCardSettlement = getAmount() - cardProcessingCost;
        double convertedAmount = netCardSettlement * getExchangeRate();
        requireFiniteResult(convertedAmount);

        double settlementYears = getSettlementDays() / 365.0;
        double discountFactor = Math.pow(1 + getAnnualDiscountRate(), settlementYears);
        requireFiniteResult(discountFactor);

        double effectiveSettlementValue = convertedAmount / discountFactor;
        return requireFiniteResult(effectiveSettlementValue);
    }

    @Override
    public String toString() {
        return getBasicPaymentInformation() + String.format(
                "%n    interchangeRate=%.4f, networkRate=%.4f, processorRate=%.4f, "
                + "fixedProcessorFee=%.2f %s, crossBorderRate=%.4f, international=%s"
                + "%n    effectiveSettlementValue=%.2f EUR; interchangePlusCost=%.2f %s",
                interchangeRate, networkRate, processorRate, fixedProcessorFee, getCurrency(),
                crossBorderRate, international, calculateEffectiveSettlementValue(),
                calculateInterchangePlusCost(), getCurrency());
    }
}
