package payments;

import java.util.Locale;

public class InternationalBankTransfer extends Payment {
    private final double senderBankFee;
    private final double correspondentBankFee;
    private final double receiverBankFee;
    private final double fxSpread;

    public InternationalBankTransfer(String transactionId, double amount, String currency,
                                     double exchangeRate, int settlementDays, double annualDiscountRate,
                                     double senderBankFee, double correspondentBankFee,
                                     double receiverBankFee, double fxSpread) {
        super(transactionId, amount, currency, exchangeRate, settlementDays, annualDiscountRate);
        this.senderBankFee = requireNonNegative("senderBankFee", senderBankFee);
        this.correspondentBankFee = requireNonNegative("correspondentBankFee", correspondentBankFee);
        this.receiverBankFee = requireNonNegative("receiverBankFee", receiverBankFee);
        this.fxSpread = requireRate("fxSpread", fxSpread, false);
    }

    public double getSenderBankFee() { return senderBankFee; }
    public double getCorrespondentBankFee() { return correspondentBankFee; }
    public double getReceiverBankFee() { return receiverBankFee; }
    public double getFxSpread() { return fxSpread; }

    @Override
    public double calculateEffectiveSettlementValue() {
        double amountAfterFees = getAmount() - senderBankFee - correspondentBankFee;
        double convertedAmount = amountAfterFees * getExchangeRate() * (1 - fxSpread);
        double netBankSettlement = convertedAmount - receiverBankFee;
        requireFiniteResult(netBankSettlement);

        double settlementYears = getSettlementDays() / 365.0;
        double discountFactor = Math.pow(1 + getAnnualDiscountRate(), settlementYears);
        requireFiniteResult(discountFactor);

        double effectiveSettlementValue = netBankSettlement / discountFactor;
        return requireFiniteResult(effectiveSettlementValue);
    }

    // targetAmount is the nominal EUR receipt at settlement, before discounting.
    public double calculateRequiredSendAmount(double targetAmount) {
        requirePositive("targetAmount", targetAmount);
        return requireFiniteResult((targetAmount + receiverBankFee)
                / (getExchangeRate() * (1 - fxSpread)) + senderBankFee + correspondentBankFee);
    }

    @Override
    public String toString() {
        return getBasicPaymentInformation() + String.format(Locale.ROOT,
                "%n    senderBankFee=%.2f %s, correspondentBankFee=%.2f %s, "
                + "receiverBankFee=%.2f EUR, fxSpread=%.4f"
                + "%n    effectiveSettlementValue=%.2f EUR; requiredSendAmount(target=1000.00 EUR)=%.2f %s",
                senderBankFee, getCurrency(), correspondentBankFee, getCurrency(), receiverBankFee,
                fxSpread, calculateEffectiveSettlementValue(), calculateRequiredSendAmount(1000), getCurrency());
    }
}
