package payments;

import java.util.Locale;

public class DigitalWalletPayment extends Payment {
    private final double walletFeeRate;
    private final double fixedWalletFee;
    private final double fxSpread;
    private final double instantPayoutRate;
    private final double minimumInstantFee;
    private final boolean instantPayout;

    public DigitalWalletPayment(String transactionId, double amount, String currency, double exchangeRate,
                                int settlementDays, double annualDiscountRate, double walletFeeRate,
                                double fixedWalletFee, double fxSpread, double instantPayoutRate,
                                double minimumInstantFee, boolean instantPayout) {
        super(transactionId, amount, currency, exchangeRate, settlementDays, annualDiscountRate);
        this.walletFeeRate = requireRate("walletFeeRate", walletFeeRate, true);
        this.fixedWalletFee = requireNonNegative("fixedWalletFee", fixedWalletFee);
        this.fxSpread = requireRate("fxSpread", fxSpread, false);
        this.instantPayoutRate = requireRate("instantPayoutRate", instantPayoutRate, true);
        this.minimumInstantFee = requireNonNegative("minimumInstantFee", minimumInstantFee);
        this.instantPayout = instantPayout;
    }

    public double getWalletFeeRate() { return walletFeeRate; }
    public double getFixedWalletFee() { return fixedWalletFee; }
    public double getFxSpread() { return fxSpread; }
    public double getInstantPayoutRate() { return instantPayoutRate; }
    public double getMinimumInstantFee() { return minimumInstantFee; }
    public boolean isInstantPayout() { return instantPayout; }

    @Override
    public double calculateEffectiveSettlementValue() {
        double walletFee = getAmount() * walletFeeRate + fixedWalletFee;
        double fxCost = getAmount() * fxSpread;
        double instantPayoutFee = 0;
        int actualSettlementDays = getSettlementDays();
        if (instantPayout) {
            instantPayoutFee = Math.max(getAmount() * instantPayoutRate, minimumInstantFee);
            actualSettlementDays = 0;
        }

        double netWalletSettlement = getAmount() - walletFee - fxCost - instantPayoutFee;
        requireFiniteResult(netWalletSettlement);
        double convertedAmount = netWalletSettlement * getExchangeRate();
        requireFiniteResult(convertedAmount);

        double settlementYears = actualSettlementDays / 365.0;
        double discountFactor = Math.pow(1 + getAnnualDiscountRate(), settlementYears);
        requireFiniteResult(discountFactor);

        double effectiveSettlementValue = convertedAmount / discountFactor;
        return requireFiniteResult(effectiveSettlementValue);
    }

    // Incremental value at the normal payout date; zero when instant payout is not selected.
    public double calculateInstantPayoutEconomicBenefit(double annualReturnRate) {
        requireNonNegative("annualReturnRate", annualReturnRate);
        if (!instantPayout) {
            return 0;
        }
        double walletFee = getAmount() * walletFeeRate + fixedWalletFee;
        double fxCost = getAmount() * fxSpread;
        double percentageFee = getAmount() * instantPayoutRate;
        double instantFee = Math.max(percentageFee, minimumInstantFee);

        double netSettlement = getAmount() - walletFee - fxCost - instantFee;
        requireFiniteResult(netSettlement);

        double settlementYears = getSettlementDays() / 365.0;
        double growthRate = Math.pow(1 + annualReturnRate, settlementYears) - 1;
        double opportunityValue = netSettlement * growthRate;
        double economicBenefit = (opportunityValue - instantFee) * getExchangeRate();
        return requireFiniteResult(economicBenefit);
    }

    @Override
    public String toString() {
        return getBasicPaymentInformation() + String.format(Locale.ROOT,
                "%n    walletFeeRate=%.4f, fixedWalletFee=%.2f %s, fxSpread=%.4f, "
                + "instantPayoutRate=%.4f, minimumInstantFee=%.2f %s, instantPayout=%s, actualDelay=%d days"
                + "%n    effectiveSettlementValue=%.2f EUR; instantPayoutEconomicBenefit(annualReturnRate=%.4f)=%.2f EUR",
                walletFeeRate, fixedWalletFee, getCurrency(), fxSpread, instantPayoutRate,
                minimumInstantFee, getCurrency(), instantPayout, instantPayout ? 0 : getSettlementDays(),
                calculateEffectiveSettlementValue(), getAnnualDiscountRate(),
                calculateInstantPayoutEconomicBenefit(getAnnualDiscountRate()));
    }
}
