package app;

import generation.PaymentGenerator;
import settlement.MerchantSettlementPlatform;
import settlement.SettlementBatch;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        PaymentGenerator generator = new PaymentGenerator(20260930L);
        List<SettlementBatch> generatedBatches = generator.generateBatches(3, 4);
        MerchantSettlementPlatform platform = createPlatform(generatedBatches);

        printSection("INITIAL TOP-LEVEL COLLECTION");
        System.out.println(platform);

        platform.sortByMaximumEffectiveSettlementValueDescending();
        printSection("TOP-LEVEL COLLECTION SORTED BY MAXIMUM OVERRIDDEN METHOD VALUE");
        System.out.println(platform);

        platform.sortByMaximumCardInterchangePlusCostDescending();
        printSection("TOP-LEVEL COLLECTION SORTED BY MAXIMUM INDIVIDUAL METHOD VALUE");
        System.out.println("Selected method: CardPayment.calculateInterchangePlusCost()");
        System.out.println(platform);
    }

    private static MerchantSettlementPlatform createPlatform(List<SettlementBatch> batches) {
        MerchantSettlementPlatform platform = new MerchantSettlementPlatform();
        for (SettlementBatch batch : batches) {
            platform.addBatch(batch);
        }
        return platform;
    }

    private static void printSection(String title) {
        System.out.println("\n=== " + title + " ===");
    }
}
