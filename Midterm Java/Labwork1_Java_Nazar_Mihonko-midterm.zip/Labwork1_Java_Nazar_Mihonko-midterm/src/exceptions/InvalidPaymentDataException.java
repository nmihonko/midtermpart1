package exceptions;

public class InvalidPaymentDataException extends IllegalArgumentException {
    public InvalidPaymentDataException(String message) {
        super(message);
    }
}
