# Simple tests: requirement 10

The fourth-subclass extension adds BNPL net/gross numerical tests and boundary/integration checks to the same two runners. See BNPL_EXTENSION.md for their inputs, independent arithmetic and model assumptions. The eleven original boundary examples below remain; additional BNPL checks are recorded in test-results.txt.

Run tests.CalculationTests and tests.BoundaryTests in IDEA with the project root as the working directory. Results are saved in test-results.txt.

## Reading a calculation test

Create an object with known inputs, set the independently calculated expected value, call the calculation method, and print Math.abs(actual - expected). A difference below 0.000001 EUR passes. A larger difference or NaN fails with an AssertionError. The expected constants were independently checked with Python Decimal arithmetic at 40-digit precision, not calculated using the Java payment methods.

All three main examples use amount 1000 USD, rate .9 EUR/USD, 365 days and annual discount .1. Therefore the discount factor is 1.1.

### Card

Inputs: interchange=.01, network=.002, processor=.003, fixed=.2 USD, crossBorder=.005, international=true.
Fees = 10 + 2 + 3 + .2 + 5 = 20.2 USD.
Net = 979.8 USD.
Expected = 979.8 * .9 / 1.1 = 801.654545454545... EUR.

### Bank

Inputs: sender=10 USD, correspondent=5 USD, receiver=3 EUR, spread=.02.
After source fees = 1000 - 10 - 5 = 985 USD.
Converted = 985 * .9 * .98 = 868.77 EUR.
After receiver fee = 865.77 EUR.
Expected = 865.77 / 1.1 = 787.063636363636... EUR.

### Wallet

Inputs: walletFeeRate=.02, fixed=.3 USD, spread=.01, instantRate=.01, minimum=2 USD, instant=false.
Wallet fee = 20.3 USD. FX cost = 10 USD. Instant fee = 0.
Net = 969.7 USD.
Expected = 969.7 * .9 / 1.1 = 793.390909090909... EUR.

### Seven-day card

Same inputs as the card example, except days=7.
Expected = 979.8 * .9 / (1.1^(7/365)) = 880.209623021881860... EUR.
This extra case detects accidentally using integer division days/365 instead of days/365.0.

Each numerical test prints inputs, formula, expected result, actual result and absolute difference. See test-results.txt for the latest actual results.

## Eleven boundary tests

| Test | Expected behavior |
|---|---|
| Zero fees/delay/discount | Amount 100 stays 100. |
| Fee rate 1 | Allowed; amount 100 becomes 0. |
| Fee rate 1.01 | Rejected. |
| FX spread 1 | Rejected (exclusive upper bound). |
| Amount -100 | Rejected. |
| Amount 0 | Rejected. |
| Empty batch | All four statistics are NaN (unavailable). |
| Single payment of 100 | Mean/min/max are 100; SD is 0. |
| Values 100 and 300 | Mean is 200; population SD is 100. |
| Instant minimum fee | Amount 10, percentage fee .10, minimum 2: value 8 without delay discount. |
| Malformed file row | Report line 1 and still load the valid payment of 100 on line 2. |

BoundaryTests uses simple try/catch blocks for invalid objects. Its check(description, correct) helper only prints PASS or throws an error. Exact equality is used only for these exactly representable examples; the principal financial calculations use a tolerance.

data/test-payments.csv has just two lines: an incomplete record and a valid zero-fee card. It is independent of the larger demonstration CSV.

## Critical evaluation

- Nonzero fees and an exchange rate different from 1 help detect missing terms or wrong conversion order.
- A one-year example is easy to calculate but cannot detect integer division in the delay. The seven-day case fills that gap.
- A single-payment SD of zero is not enough: a broken method that always returns zero would pass. Values 100 and 300 detect that error and distinguish population SD (100) from sample SD (about 141.42).
- Invalid-input tests must verify that an exception occurs. A crash is not accepted as proof that a reader can continue.
- The malformed-file test checks rejection, the line number and the next valid payment, not just the error count.
- This smaller suite is deliberately not exhaustive. It does not retain every previous parser/nonfinite-input/individual-method check. It demonstrates the required principal and boundary cases without claiming full regression coverage.
- The domain defines no maximum amount or smallest positive real amount. Tests demonstrate specified limits using rates and zero values instead of inventing an amount limit.
