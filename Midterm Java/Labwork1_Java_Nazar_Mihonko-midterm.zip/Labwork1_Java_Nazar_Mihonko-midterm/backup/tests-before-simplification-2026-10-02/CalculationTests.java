package tests;

import payments.CardPayment;
import payments.BNPLPayment;
import payments.InternationalBankTransfer;
import payments.DigitalWalletPayment;

public class CalculationTests {
    public static void main(String[] args) {
        testCardPayment();
        testBankTransfer();
        testWalletPayment();
        testSevenDayDelay();
        testBNPLPayment();
        System.out.println("\nAll calculation tests passed.");
    }

    private static void testBNPLPayment() {
        System.out.println("\nBNPL: amount=1200 USD, EUR/USD=.9, delay=7 days, annual rate=.12, installments=3, fee=.04, fixed=2 USD");
        BNPLPayment payment = new BNPLPayment("N", 1200, "USD", .9, 7, .12, 3, .04, 2);
        System.out.println("Formula: sum for k=1..3 of ((1200 - 48 - 2)/3)/(1.12^(k/12.0 + 7/365.0)), then multiply by .9");
        double expected = 1013.4593884484374;
        double actual = payment.calculateEffectiveSettlementValue();
        double difference = Math.abs(actual - expected);
        System.out.println("Expected EUR: " + expected);
        System.out.println("Actual EUR: " + actual);
        System.out.println("Difference: " + difference);
        if (difference < 0.000001) {
            System.out.println("PASS");
        } else {
            throw new AssertionError("BNPL effective value failed");
        }

        System.out.println("Gross installment formula: 400/1.12^(1/12.0) + 400/1.12^(2/12.0) + 400/1.12^(3/12.0)");
        double expectedGross = 1177.5819869019288;
        double actualGross = payment.calculatePresentValueOfInstallments();
        double grossDifference = Math.abs(actualGross - expectedGross);
        System.out.println("Expected USD: " + expectedGross);
        System.out.println("Actual USD: " + actualGross);
        System.out.println("Difference: " + grossDifference);
        if (grossDifference < 0.000001) {
            System.out.println("PASS");
        } else {
            throw new AssertionError("BNPL gross installment value failed");
        }
    }

    private static void testCardPayment() {
        System.out.println("\nCard: amount=1000 USD, EUR/USD=.9, days=365, discount=.1; interchange=.01, network=.002, processor=.003, fixed=.2, crossBorder=.005, international=true");
        System.out.println("Formula: (1000 - (10 + 2 + 3 + .2 + 5)) * .9 / 1.1");
        CardPayment payment = new CardPayment("C", 1000, "USD", .9, 365, .1,
                .01, .002, .003, .2, .005, true);

        // Expected result was calculated independently before running Java.
        double expected = 801.6545454545455;
        double actual = payment.calculateEffectiveSettlementValue();
        double difference = Math.abs(actual - expected);

        System.out.println("Expected EUR: " + expected);
        System.out.println("Actual EUR: " + actual);
        System.out.println("Difference: " + difference);
        if (difference < 0.000001) {
            System.out.println("PASS");
        } else {
            throw new AssertionError("testCardPayment failed");
        }
    }

    private static void testBankTransfer() {
        System.out.println("\nBank: amount=1000 USD, EUR/USD=.9, days=365, discount=.1; sender=10, correspondent=5, receiver=3 EUR, spread=.02");
        System.out.println("Formula: ((1000 - 10 - 5) * .9 * .98 - 3) / 1.1");
        InternationalBankTransfer payment = new InternationalBankTransfer("B", 1000, "USD", .9,
                365, .1, 10, 5, 3, .02);

        // Expected result was calculated independently before running Java.
        double expected = 787.0636363636364;
        double actual = payment.calculateEffectiveSettlementValue();
        double difference = Math.abs(actual - expected);

        System.out.println("Expected EUR: " + expected);
        System.out.println("Actual EUR: " + actual);
        System.out.println("Difference: " + difference);
        if (difference < 0.000001) {
            System.out.println("PASS");
        } else {
            throw new AssertionError("testBankTransfer failed");
        }
    }

    private static void testWalletPayment() {
        System.out.println("\nWallet: amount=1000 USD, EUR/USD=.9, days=365, discount=.1; fee=.02, fixed=.3, spread=.01, instantRate=.01, minimum=2, instant=false");
        System.out.println("Formula: (1000 - 20 - .3 - 10) * .9 / 1.1");
        DigitalWalletPayment payment = new DigitalWalletPayment("W", 1000, "USD", .9,
                365, .1, .02, .3, .01, .01, 2, false);

        // Expected result was calculated independently before running Java.
        double expected = 793.3909090909091;
        double actual = payment.calculateEffectiveSettlementValue();
        double difference = Math.abs(actual - expected);

        System.out.println("Expected EUR: " + expected);
        System.out.println("Actual EUR: " + actual);
        System.out.println("Difference: " + difference);
        if (difference < 0.000001) {
            System.out.println("PASS");
        } else {
            throw new AssertionError("testWalletPayment failed");
        }
    }

    private static void testSevenDayDelay() {
        System.out.println("\nCard: same inputs as the first test, but days=7");
        System.out.println("Formula: 979.8 * .9 / Math.pow(1.1, 7 / 365.0)");
        CardPayment payment = new CardPayment("7D", 1000, "USD", .9, 7, .1,
                .01, .002, .003, .2, .005, true);

        // Expected result was calculated independently before running Java.
        double expected = 880.2096230218819;
        double actual = payment.calculateEffectiveSettlementValue();
        double difference = Math.abs(actual - expected);

        System.out.println("Expected EUR: " + expected);
        System.out.println("Actual EUR: " + actual);
        System.out.println("Difference: " + difference);
        if (difference < 0.000001) {
            System.out.println("PASS");
        } else {
            throw new AssertionError("testSevenDayDelay failed");
        }
    }

}
