package tests;

import exceptions.InvalidPaymentDataException;
import input.PaymentFileReader;
import payments.CardPayment;
import payments.BNPLPayment;
import payments.Payment;
import generation.PaymentGenerator;
import payments.DigitalWalletPayment;
import payments.InternationalBankTransfer;
import settlement.SettlementBatch;
import settlement.MerchantSettlementPlatform;
import java.io.IOException;
import java.nio.file.Path;

public class BoundaryTests {
    public static void main(String[] args) throws IOException {
        testZeroFeesAndDelay();
        testMaximumFeeRate();
        testRateAboveMaximum();
        testFxSpreadAtOne();
        testNegativeAmount();
        testZeroAmount();
        testEmptyBatch();
        testSinglePayment();
        testPopulationStandardDeviation();
        testInstantMinimumFee();
        testMalformedFileRecord();
        testBNPLBoundaries();
        testBNPLCollectionsAndSorting();
        testBNPLFileAndGeneration();
        System.out.println("\nAll boundary tests passed.");
    }

    private static void testBNPLBoundaries() {
        BNPLPayment single = new BNPLPayment("ONE", 100, "EUR", 1, 0, 0, 1, .1, 2);
        check("BNPL one installment and zero discount: net=88", single.calculateEffectiveSettlementValue() == 88);
        check("BNPL gross value before fees=100", single.calculatePresentValueOfInstallments() == 100);
        BNPLPayment maximum = new BNPLPayment("MAX", 360, "EUR", 1, 0, 0, 36, 0, 0);
        check("BNPL 36 installments allowed", maximum.calculateEffectiveSettlementValue() == 360);
        for (int count : new int[] {0, -1, 37}) {
            boolean rejected = false;
            try {
                new BNPLPayment("BAD", 100, "EUR", 1, 0, 0, count, 0, 0);
            } catch (InvalidPaymentDataException exception) {
                rejected = true;
            }
            check("BNPL invalid installment count " + count, rejected);
        }
    }

    private static void testBNPLCollectionsAndSorting() {
        SettlementBatch mixed = new SettlementBatch("Mixed");
        mixed.addPayment(new CardPayment("C", 100, "EUR", 1, 0, 0, 0, 0, 0, 0, 0, false));
        mixed.addPayment(new BNPLPayment("N", 300, "EUR", 1, 0, 0, 3, 0, 0));
        check("BNPL mixed batch mean=200", mixed.calculateAverage() == 200);
        check("BNPL mixed batch min/max/SD", mixed.calculateMinimum() == 100
                && mixed.calculateMaximum() == 300 && mixed.calculateStandardDeviation() == 100);
        SettlementBatch low = new SettlementBatch("Low");
        low.addPayment(new BNPLPayment("LOW", 50, "EUR", 1, 0, 0, 1, 0, 0));
        MerchantSettlementPlatform platform = new MerchantSettlementPlatform();
        platform.addBatch(mixed);
        platform.addBatch(low);
        platform.sortByAverageAscending();
        check("BNPL average ascending", platform.getBatches().get(0) == low);
        platform.sortByAverageDescending();
        check("BNPL average descending", platform.getBatches().get(0) == mixed);
        platform.sortByStandardDeviation();
        check("BNPL SD sort", platform.getBatches().get(0) == low);
        platform.sortByAverageDescending();
        platform.sortByMaximum();
        check("BNPL maximum sort", platform.getBatches().get(0) == low);
    }

    private static void testBNPLFileAndGeneration() throws IOException {
        PaymentFileReader reader = new PaymentFileReader();
        MerchantSettlementPlatform loaded = reader.read(Path.of("data", "bnpl-test.csv"));
        check("BNPL CSV rejects zero and fractional counts, then continues",
                reader.getErrors().size() == 2 && reader.getLoadedPaymentCount() == 1);
        Payment payment = loaded.getBatches().get(0).getPayments().get(0);
        check("BNPL CSV constructs correct subclass", payment.getClass() == BNPLPayment.class);
        check("BNPL CSV calculation", payment.calculateEffectiveSettlementValue() == 88);
        PaymentGenerator generator = new PaymentGenerator(42);
        for (SettlementBatch batch : generator.generateBatches(3, 4)) {
            boolean foundBNPL = false;
            for (Payment generated : batch.getPayments()) {
                if (generated.getClass() == BNPLPayment.class) {
                    foundBNPL = true;
                }
            }
            check("Generated batch includes BNPL", foundBNPL);
        }
    }

    private static void testZeroFeesAndDelay() {
        CardPayment payment = new CardPayment("ZERO", 100, "EUR", 1, 0, 0,
                0, 0, 0, 0, 0, false);
        check("Zero fees and delay: value stays 100", payment.calculateEffectiveSettlementValue() == 100);
    }

    private static void testMaximumFeeRate() {
        CardPayment payment = new CardPayment("MAX", 100, "EUR", 1, 0, 0,
                1, 0, 0, 0, 0, false);
        check("Fee rate 1 is allowed: value becomes 0", payment.calculateEffectiveSettlementValue() == 0);
    }

    private static void testRateAboveMaximum() {
        boolean rejected = false;
        try {
            new CardPayment("BAD", 100, "EUR", 1, 0, 0, 1.01, 0, 0, 0, 0, false);
        } catch (InvalidPaymentDataException exception) {
            rejected = true;
        }
        check("Fee rate above 1 is rejected", rejected);
    }

    private static void testFxSpreadAtOne() {
        boolean rejected = false;
        try {
            new InternationalBankTransfer("BAD", 100, "EUR", 1, 0, 0, 0, 0, 0, 1);
        } catch (InvalidPaymentDataException exception) {
            rejected = true;
        }
        check("FX spread 1 is rejected", rejected);
    }

    private static void testNegativeAmount() {
        boolean rejected = false;
        try {
            new CardPayment("BAD", -100, "EUR", 1, 0, 0, 0, 0, 0, 0, 0, false);
        } catch (InvalidPaymentDataException exception) {
            rejected = true;
        }
        check("Negative amount is rejected", rejected);
    }

    private static void testZeroAmount() {
        boolean rejected = false;
        try {
            new CardPayment("BAD", 0, "EUR", 1, 0, 0, 0, 0, 0, 0, 0, false);
        } catch (InvalidPaymentDataException exception) {
            rejected = true;
        }
        check("Zero amount is rejected", rejected);
    }

    private static void testEmptyBatch() {
        SettlementBatch batch = new SettlementBatch("Empty");
        check("Empty batch: all statistics unavailable",
                Double.isNaN(batch.calculateAverage())
                && Double.isNaN(batch.calculateMinimum())
                && Double.isNaN(batch.calculateMaximum())
                && Double.isNaN(batch.calculateStandardDeviation()));
    }

    private static void testSinglePayment() {
        SettlementBatch batch = new SettlementBatch("Single");
        batch.addPayment(new CardPayment("ONE", 100, "EUR", 1, 0, 0, 0, 0, 0, 0, 0, false));
        check("One payment: mean/min/max=100 and SD=0",
                batch.calculateAverage() == 100
                && batch.calculateMinimum() == 100
                && batch.calculateMaximum() == 100
                && batch.calculateStandardDeviation() == 0);
    }

    private static void testPopulationStandardDeviation() {
        SettlementBatch batch = new SettlementBatch("Two payments");
        batch.addPayment(new CardPayment("A", 100, "EUR", 1, 0, 0, 0, 0, 0, 0, 0, false));
        batch.addPayment(new CardPayment("B", 300, "EUR", 1, 0, 0, 0, 0, 0, 0, 0, false));
        // Mean = 200. SD = sqrt(((100-200)^2 + (300-200)^2) / 2) = 100.
        check("Values 100 and 300: mean=200 and population SD=100",
                batch.calculateAverage() == 200 && batch.calculateStandardDeviation() == 100);
    }

    private static void testInstantMinimumFee() {
        DigitalWalletPayment payment = new DigitalWalletPayment("MIN", 10, "EUR", 1,
                7, .1, 0, 0, 0, .01, 2, true);
        // Percentage fee is .10; minimum fee is 2. Instant payout has zero actual delay.
        check("Instant minimum fee: 10 - 2 = 8", payment.calculateEffectiveSettlementValue() == 8);
    }

    private static void testMalformedFileRecord() throws IOException {
        PaymentFileReader reader = new PaymentFileReader();
        MerchantSettlementPlatform platform = reader.read(Path.of("data", "test-payments.csv"));
        // First row is malformed. Second row is a valid card with no fees.
        check("Bad row is reported and the following valid payment loads",
                reader.getErrors().size() == 1
                && reader.getErrors().get(0).startsWith("Line 1:")
                && reader.getLoadedPaymentCount() == 1
                && platform.getBatches().size() == 1
                && platform.getBatches().get(0).getPayments().get(0).getTransactionId().equals("VALID")
                && platform.getBatches().get(0).calculateAverage() == 100);
    }

    // A simple pass/fail printer shared by the short boundary examples.
    private static void check(String description, boolean correct) {
        if (correct) {
            System.out.println("PASS: " + description);
        } else {
            throw new AssertionError("FAIL: " + description);
        }
    }
}
